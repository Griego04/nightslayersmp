NIGHTSLAYER SMP WEBSITE

Files
- index.html: responsive single-page website; no build tools required.

Preview
- Open index.html in a browser on your Chromebook.

Publish free with GitHub Pages
1. Sign in or create a GitHub account at https://github.com/
2. Create a new public repository, e.g. nightslayer-smp-site.
3. Upload index.html (and this README if you want).
4. In repository Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
5. Wait for GitHub Pages to publish and use the URL shown in Settings > Pages.

Important
- The website is a static informational site. It does not itself host a Minecraft server.
- /shop is shown as a planned in-game command, not an installed command. To make it work, the Bedrock server needs a compatible add-on/script and persistent economy storage.
- Starting balance $100, selling confirmation, keeping Money on death, and buy/sell shop are the intended design settings. Example item prices are placeholders.
- Server address nightslayersmp.me and port 19132 are displayed as provided; website does not verify server status.
